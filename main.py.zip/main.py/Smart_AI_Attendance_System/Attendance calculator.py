import os
import json
from datetime import datetime, date, timedelta
from database import (
    get_attendance_report,
    get_all_subjects,
    get_all_students,
    get_connection
)

# ─────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────
BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
SUBJECTS_FILE = os.path.join(BASE_DIR, "subjects.json")

# ─────────────────────────────────────────────
#  STEP 1 — Load subjects.json
# ─────────────────────────────────────────────
print("=" * 60)
print("   ATTENDANCE CALCULATOR")
print("=" * 60 + "\n")

if not os.path.exists(SUBJECTS_FILE):
    print("❌ subjects.json not found!")
    exit()

with open(SUBJECTS_FILE) as f:
    config = json.load(f)

ALERT_THRESHOLD = config.get("alert_threshold", 60)
today           = date.today()
subjects_map    = {s["code"]: s for s in config["subjects"]}

print(f"📅 Semester  : {config['semester']['name']}")
print(f"   Today     : {today.strftime('%d %b %Y')}")
print(f"   Threshold : {ALERT_THRESHOLD}%\n")

# ─────────────────────────────────────────────
#  STEP 2 — Load Classes Held from DB
# ─────────────────────────────────────────────
conn         = get_connection()
classes_held = {}

for code in subjects_map:
    count = conn.execute("""
        SELECT COUNT(*) FROM class_schedule
        WHERE subject_code = ?
    """, (code,)).fetchone()[0]
    classes_held[code] = count

conn.close()

# ─────────────────────────────────────────────
#  STEP 3 — Expected Classes from Timetable
# ─────────────────────────────────────────────
DAY_MAP   = {"Monday":0, "Tuesday":1, "Wednesday":2,
             "Thursday":3, "Friday":4, "Saturday":5, "Sunday":6}
sem_start = datetime.strptime(
    config["semester"]["start"], "%Y-%m-%d").date()
sem_end   = datetime.strptime(
    config["semester"]["end"], "%Y-%m-%d").date()

def count_expected(code):
    subj = subjects_map.get(code)
    if not subj: return 0
    days  = [DAY_MAP[d] for d in subj.get("days", [])]
    count = 0
    check = sem_start
    end   = min(today, sem_end)
    while check <= end:
        if check.weekday() in days:
            count += 1
        check += timedelta(days=1)
    return count

# ─────────────────────────────────────────────
#  STEP 4 — Print Subject-wise Class Count
# ─────────────────────────────────────────────
print(f"{'─'*65}")
print(f"  Classes Held Per Subject")
print(f"{'─'*65}")
print(f"  {'Subject':<25} {'Code':<12} {'Held':>6} "
      f"{'Expected':>9} {'Total':>6}")
print(f"{'─'*65}")

for code, subj in subjects_map.items():
    held     = classes_held.get(code, 0)
    exp      = count_expected(code)
    total    = subj["total_classes"]
    # use actual if available else timetable expected
    display  = held if held > 0 else exp
    print(f"  {subj['name']:<25} {code:<12} "
          f"{held:>6} {exp:>9} {total:>6}")

print(f"{'─'*65}\n")

# ─────────────────────────────────────────────
#  STEP 5 — Get Attendance from DB
# ─────────────────────────────────────────────
all_students = {s["student_id"]: s for s in get_all_students()}
report       = get_attendance_report()

if not all_students:
    print("❌ No students found in database.")
    print("   Run database.py first.")
    exit()

# ─────────────────────────────────────────────
#  STEP 6 — Calculate Percentages
# ─────────────────────────────────────────────
results    = []
defaulters = []

for r in report:
    code    = r["subject_code"]
    subj    = subjects_map.get(code, {})
    held    = classes_held.get(code, 0)
    if held == 0:
        held = count_expected(code)

    total   = subj.get("total_classes", 1) or 1
    present = r["present"]
    absent  = max(0, held - present)

    current_pct   = round((present / held  * 100), 1) if held  > 0 else 0
    projected_pct = round((present / total * 100), 1) if total > 0 else 0

    # Classes needed to reach threshold
    needed = 0
    if current_pct < ALERT_THRESHOLD and held > 0:
        remaining = total - held
        x = 0
        while x <= remaining:
            if (present + x) / (held + x) * 100 >= ALERT_THRESHOLD:
                needed = x
                break
            x += 1
        else:
            needed = -1

    status = "OK" if current_pct >= ALERT_THRESHOLD else "LOW"

    result = {
        "student_id"   : r["student_id"],
        "name"         : r["name"],
        "enrollment"   : r["enrollment"],
        "email"        : r["email"],
        "phone"        : r["phone"],
        "subject_code" : code,
        "subject_name" : subj.get("name", code),
        "days"         : ", ".join(
                         [d[:3] for d in subj.get("days", [])]),
        "time"         : subj.get("time", ""),
        "present"      : present,
        "absent"       : absent,
        "held"         : held,
        "total"        : total,
        "current_pct"  : current_pct,
        "projected_pct": projected_pct,
        "needed"       : needed,
        "status"       : status,
        "is_low"       : current_pct < ALERT_THRESHOLD,
    }
    results.append(result)
    if current_pct < ALERT_THRESHOLD and held > 0:
        defaulters.append(result)

# ─────────────────────────────────────────────
#  STEP 7 — Print Full Attendance Report
# ─────────────────────────────────────────────
print(f"{'─'*75}")
print(f"  ATTENDANCE REPORT — {today.strftime('%d %B %Y')}")
print(f"{'─'*75}")
print(f"  {'Name':<18} {'Subject':<22} {'P':>3} {'A':>3} "
      f"{'Held':>5} {'Total':>5} {'Now%':>6} {'End%':>6}  Status")
print(f"{'─'*75}")

prev_student = ""
for r in results:
    if r["name"] != prev_student and prev_student != "":
        print(f"  {'─'*71}")
    prev_student = r["name"]
    icon = "✅" if r["status"] == "OK" else "⚠️ "
    print(f"  {r['name']:<18} {r['subject_name']:<22} "
          f"{r['present']:>3} {r['absent']:>3} "
          f"{r['held']:>5} {r['total']:>5} "
          f"{r['current_pct']:>5.1f}% "
          f"{r['projected_pct']:>5.1f}%  {icon} {r['status']}")

print(f"{'─'*75}")
print(f"  P=Present  A=Absent  Held=Classes run  "
      f"Now%=Current  End%=Projected")
print(f"{'─'*75}\n")

# ─────────────────────────────────────────────
#  STEP 8 — Per Subject Summary
# ─────────────────────────────────────────────
print(f"{'─'*75}")
print(f"  PER SUBJECT SUMMARY")
print(f"{'─'*75}")

for code, subj in sorted(subjects_map.items()):
    held         = classes_held.get(code, 0)
    subj_results = [r for r in results
                    if r["subject_code"] == code]
    if not subj_results:
        continue
    ok_count  = sum(1 for r in subj_results
                    if r["status"] == "OK")
    low_count = sum(1 for r in subj_results
                    if r["status"] == "LOW")

    print(f"\n  📚 {subj['name']} ({code.upper()})")
    print(f"     Classes held : {held} / {subj['total_classes']}")
    print(f"     Days         : "
          f"{', '.join(subj.get('days', []))}")
    print(f"     Students OK  : {ok_count}")
    print(f"     Defaulters   : {low_count}")

    for r in subj_results:
        icon = "✅" if r["status"] == "OK" else "⚠️ "
        print(f"     {icon} {r['name']:<20} "
              f"{r['present']}/{r['held']} "
              f"= {r['current_pct']}%")

print(f"\n{'─'*75}\n")

# ─────────────────────────────────────────────
#  STEP 9 — Defaulter List
# ─────────────────────────────────────────────
if defaulters:
    print(f"⚠️  DEFAULTERS (below {ALERT_THRESHOLD}%)")
    print(f"{'─'*75}")
    for d in defaulters:
        can_recover = d["needed"] != -1
        print(f"  👤 {d['name']} ({d['enrollment']})")
        print(f"     Subject    : {d['subject_name']} "
              f"| {d['days']} | {d['time']}")
        print(f"     Attended   : {d['present']} / "
              f"{d['held']} classes held")
        print(f"     Absent     : {d['absent']} classes missed")
        print(f"     Current %  : {d['current_pct']}%")
        print(f"     Projected %: {d['projected_pct']}% "
              f"(end of semester)")
        if can_recover:
            print(f"     Recovery   : Attend next {d['needed']} "
                  f"class(es) to reach {ALERT_THRESHOLD}%")
        else:
            print(f"     Recovery   : ❌ Cannot reach "
                  f"{ALERT_THRESHOLD}% even attending all remaining")
        print(f"     Email      : {d['email']}")
        print(f"     Phone      : {d['phone']}")
        print()
else:
    print(f"✅ No defaulters! All students above {ALERT_THRESHOLD}%\n")

# ─────────────────────────────────────────────
#  STEP 10 — Summary
# ─────────────────────────────────────────────
print(f"{'─'*75}")
print(f"  Summary")
print(f"{'─'*75}")
print(f"  Total Students : {len(all_students)}")
print(f"  Total Subjects : {len(subjects_map)}")
print(f"  Defaulters     : {len(defaulters)}")
print(f"  Data Source    : attendance.db ✅")
print(f"  Threshold      : {ALERT_THRESHOLD}%")
print(f"  Generated      : "
      f"{datetime.now().strftime('%d-%m-%Y %H:%M:%S')}")
print(f"{'─'*75}\n")

if defaulters:
    print(f"📧 {len(defaulters)} student(s) need alerts "
          f"→ Run alert_system.py next")
else:
    print("✅ No alerts needed.")

# ── Used by alert_system.py ──
def get_defaulters():
    return defaulters

def get_all_results():
    return results