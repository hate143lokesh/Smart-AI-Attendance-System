from flask import (Flask, render_template, jsonify,
                   request, redirect, url_for,
                   session, flash)
import os, json, hashlib
from datetime import datetime, date, timedelta
from database import (
    get_attendance_report, get_all_students,
    get_all_subjects, get_db_stats, get_connection
)

app         = Flask(__name__)
app.secret_key = "smartai_attendance_2026_medicaps"

BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
SUBJECTS_FILE = os.path.join(BASE_DIR, "subjects.json")

# ─────────────────────────────────────────────
#  USER ACCOUNTS
#  Add more teachers or students here
# ─────────────────────────────────────────────
USERS = {
    # role: teacher
    "admin": {
        "password": "admin123",
        "role"    : "teacher",
        "name"    : "Admin",
    },
    "teacher": {
        "password": "teacher123",
        "role"    : "teacher",
        "name"    : "Prof. Sharma",
    },
}
# Students are loaded from DB dynamically
# Login: enrollment number as username
# Password: last 4 digits of phone

# ─────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────
def load_config():
    with open(SUBJECTS_FILE) as f:
        return json.load(f)

def load_data():
    config          = load_config()
    ALERT_THRESHOLD = config.get("alert_threshold", 60)
    semester        = config["semester"]
    subjects_map    = {s["code"]: s for s in config["subjects"]}
    all_students    = {s["student_id"]: s
                       for s in get_all_students()}
    report          = get_attendance_report()
    stats           = get_db_stats()
    conn            = get_connection()

    classes_held = {}
    for code in subjects_map:
        count = conn.execute(
            "SELECT COUNT(*) FROM class_schedule "
            "WHERE subject_code=?",
            (code,)).fetchone()[0]
        classes_held[code] = count

    DAY_MAP   = {"Monday":0,"Tuesday":1,"Wednesday":2,
                 "Thursday":3,"Friday":4,"Saturday":5,"Sunday":6}
    today     = date.today()
    sem_start = datetime.strptime(
        semester["start"],"%Y-%m-%d").date()
    sem_end   = datetime.strptime(
        semester["end"],"%Y-%m-%d").date()

    def expected(code):
        subj  = subjects_map.get(code)
        if not subj: return 0
        days  = [DAY_MAP[d] for d in subj.get("days",[])]
        count = 0
        check = sem_start
        end   = min(today, sem_end)
        while check <= end:
            if check.weekday() in days: count += 1
            check += timedelta(days=1)
        return count

    results = []
    for r in report:
        code  = r["subject_code"]
        subj  = subjects_map.get(code, {})
        held  = classes_held.get(code,0) or expected(code)
        total = subj.get("total_classes",1) or 1
        proj  = round((r["present"] / total * 100), 1)
        results.append({
            **r, "held": held, "proj": proj,
            "subject_name": subj.get("name", code)
        })

    conn.close()
    return {
        "results"        : results,
        "all_students"   : all_students,
        "subjects_map"   : subjects_map,
        "classes_held"   : classes_held,
        "ALERT_THRESHOLD": ALERT_THRESHOLD,
        "semester"       : semester,
        "today"          : today.strftime("%d %B %Y"),
        "generated"      : datetime.now().strftime(
                           "%d-%m-%Y %H:%M:%S"),
        "db_stats"       : stats,
    }

def get_subject_stats(data):
    stats = []
    for code, subj in data["subjects_map"].items():
        sr    = [r for r in data["results"]
                 if r["subject_code"]==code]
        held  = data["classes_held"].get(code,0)
        avg   = round(sum(r["pct"] for r in sr)
                      / len(sr), 1) if sr else 0
        low   = len([r for r in sr if r["status"]=="LOW"])
        stats.append({
            "name"     : subj.get("name",code),
            "code"     : code,
            "held"     : held,
            "total"    : subj.get("total_classes",0),
            "avg_pct"  : avg,
            "low_count": low,
        })
    return stats

def is_logged_in():
    return "user" in session

def get_current_user():
    return session.get("user", None)

# ─────────────────────────────────────────────
#  AUTH ROUTES
# ─────────────────────────────────────────────
@app.route("/login", methods=["GET","POST"])
def login():
    if is_logged_in():
        user = get_current_user()
        if user["role"] == "teacher":
            return redirect(url_for("index"))
        else:
            return redirect(url_for("student_portal"))

    error = None
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","").strip()
        role     = request.form.get("role","teacher")

        if role == "teacher":
            # Check teacher accounts
            if username in USERS and \
               USERS[username]["password"] == password:
                session["user"] = {
                    "username": username,
                    "name"    : USERS[username]["name"],
                    "role"    : "teacher",
                }
                return redirect(url_for("index"))
            else:
                error = "Invalid username or password"

        else:  # student login
            # Find student by enrollment number
            all_students = get_all_students()
            found = None
            for s in all_students:
                if s["enrollment"].upper() == username.upper():
                    found = s
                    break

            if found:
                # Password = last 4 digits of phone
                phone    = found.get("phone","0000")
                pwd_hash = phone[-4:] if len(phone) >= 4 else phone
                if password == pwd_hash:
                    session["user"] = {
                        "username"  : username,
                        "name"      : found["name"],
                        "role"      : "student",
                        "student_id": found["student_id"],
                        "enrollment": found["enrollment"],
                        "email"     : found["email"],
                    }
                    return redirect(url_for("student_portal"))
                else:
                    error = "Wrong password. Use last 4 digits of your phone"
            else:
                error = "Enrollment number not found"

    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ─────────────────────────────────────────────
#  TEACHER ROUTES
# ─────────────────────────────────────────────
@app.route("/")
def index():
    if not is_logged_in():
        return redirect(url_for("login"))
    user = get_current_user()
    if user["role"] == "student":
        return redirect(url_for("student_portal"))

    data          = load_data()
    results       = data["results"]
    defaulters    = [r for r in results
                     if r["status"]=="LOW" and r["held"]>0]
    total_ok      = len([r for r in results
                         if r["status"]=="OK"])
    subject_stats = get_subject_stats(data)
    return render_template("index.html",
        data=data, results=results,
        defaulters=defaulters, total_ok=total_ok,
        subject_stats=subject_stats, user=user)

@app.route("/students")
def students():
    if not is_logged_in(): return redirect(url_for("login"))
    user = get_current_user()
    if user["role"] == "student":
        return redirect(url_for("student_portal"))
    data = load_data()
    return render_template("student.html", data=data,
        subject_stats=get_subject_stats(data), user=user)

@app.route("/subjects")
def subjects():
    if not is_logged_in(): return redirect(url_for("login"))
    user = get_current_user()
    if user["role"] == "student":
        return redirect(url_for("student_portal"))
    data = load_data()
    return render_template("subjects.html", data=data,
        subject_stats=get_subject_stats(data), user=user)

# ─────────────────────────────────────────────
#  STUDENT PORTAL
# ─────────────────────────────────────────────
@app.route("/student")
def student_portal():
    if not is_logged_in(): return redirect(url_for("login"))
    user = get_current_user()
    if user["role"] == "teacher":
        return redirect(url_for("index"))

    data          = load_data()
    student_id    = user["student_id"]
    THRESHOLD     = data["ALERT_THRESHOLD"]

    # Get only this student's results
    my_results = [r for r in data["results"]
                  if r["student_id"] == student_id]

    # Overall attendance %
    overall = round(sum(r["pct"] for r in my_results)
                    / len(my_results), 1) if my_results else 0

    defaulter_subjects = [r for r in my_results
                          if r["status"] == "LOW"
                          and r["held"] > 0]

    return render_template("student_portal.html",
        user=user, data=data,
        my_results=my_results,
        overall=overall,
        defaulter_subjects=defaulter_subjects,
        subject_stats=get_subject_stats(data))

# ─────────────────────────────────────────────
#  REGISTER STUDENT (WEB)
# ─────────────────────────────────────────────
@app.route("/register-student")
def register_student_page():
    if not is_logged_in():
        return redirect(url_for("login"))
    user = get_current_user()
    if user["role"] == "student":
        return redirect(url_for("student_portal"))
    return render_template("register_student.html", user=user)

@app.route("/api/register-student", methods=["POST"])
def api_register_student():
    """Register a new student with face photos from webcam."""
    if not is_logged_in():
        return jsonify({"error": "Not logged in"}), 401

    import base64, numpy as np, cv2, pickle

    name       = request.json.get("name", "").strip()
    enrollment = request.json.get("enrollment", "").strip().upper()
    email      = request.json.get("email", "").strip().lower()
    phone      = request.json.get("phone", "").strip()
    photos     = request.json.get("photos", [])  # list of base64 images

    if not name or not enrollment or len(photos) == 0:
        return jsonify({"error": "Name, enrollment and at least 1 photo required"}), 400

    student_id = f"{enrollment}_{name.replace(' ', '_')}"
    faces_dir  = os.path.join(BASE_DIR, "faces", student_id)
    emb_dir    = os.path.join(BASE_DIR, "embeddings")
    os.makedirs(faces_dir, exist_ok=True)

    # Load ArcFace model
    face_app = get_face_app()
    if face_app is None:
        return jsonify({"error": "Face model not available"}), 500

    embeddings_list = []
    saved_count = 0

    for i, photo_b64 in enumerate(photos):
        try:
            if "," in photo_b64:
                photo_b64 = photo_b64.split(",")[1]
            img_bytes = base64.b64decode(photo_b64)
            np_arr    = np.frombuffer(img_bytes, np.uint8)
            frame     = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

            if frame is None:
                continue

            # Save photo
            img_path = os.path.join(faces_dir, f"{i+1}.jpg")
            cv2.imwrite(img_path, frame)
            saved_count += 1

            # Get embedding
            faces = face_app.get(frame)
            if len(faces) > 0:
                embeddings_list.append(
                    faces[0].normed_embedding.tolist())
        except:
            continue

    if len(embeddings_list) == 0:
        return jsonify({"error": "No faces detected in photos. Try again with better lighting."}), 400

    # Average embeddings
    avg_emb = np.mean(embeddings_list, axis=0)
    norm    = np.linalg.norm(avg_emb)
    avg_emb = (avg_emb / norm).tolist()

    # Save embedding JSON
    emb_data = {
        "name": name, "enrollment": enrollment,
        "student_id": student_id,
        "email": email or "N/A", "phone": phone or "N/A",
        "photos_taken": saved_count,
        "embedding": avg_emb
    }
    emb_path = os.path.join(emb_dir, f"{student_id}.json")
    with open(emb_path, "w") as f:
        json.dump(emb_data, f, indent=2)

    # Rebuild face_db.pkl
    face_db = {}
    for file in os.listdir(emb_dir):
        if not file.endswith(".json"):
            continue
        try:
            with open(os.path.join(emb_dir, file)) as f:
                data = json.load(f)
            face_db[data["student_id"]] = np.array(
                data["embedding"])
        except:
            continue
    with open(os.path.join(emb_dir, "face_db.pkl"), "wb") as f:
        pickle.dump(face_db, f)

    # Reset cached face_db so it reloads
    global _face_db
    _face_db = None

    # Add to SQLite database
    from database import upsert_student
    upsert_student(student_id, name, enrollment,
                   email or "N/A", phone or "N/A")

    return jsonify({
        "success": True,
        "student_id": student_id,
        "photos_saved": saved_count,
        "embeddings": len(embeddings_list),
        "total_in_db": len(face_db)
    })

# ─────────────────────────────────────────────
#  TAKE ATTENDANCE (WEB)
# ─────────────────────────────────────────────
@app.route("/take-attendance")
def take_attendance_page():
    if not is_logged_in():
        return redirect(url_for("login"))
    user = get_current_user()
    if user["role"] == "student":
        return redirect(url_for("student_portal"))
    config   = load_config()
    subjects = config["subjects"]
    return render_template("take_attendance.html",
        subjects=subjects, user=user)

# Lazy-load the face recognition model (only when needed)
_face_app = None
_face_db  = None

def get_face_app():
    global _face_app
    if _face_app is None:
        try:
            from insightface.app import FaceAnalysis
            _face_app = FaceAnalysis(name="buffalo_l", allowed_modules=["detection", "recognition"])
            _face_app.prepare(ctx_id=0, det_size=(320, 320))
            print("[OK] ArcFace model loaded for web")
        except Exception as e:
            print(f"[WARN] Could not load ArcFace: {e}")
            return None
    return _face_app

def get_face_db():
    global _face_db
    import pickle
    db_path = os.path.join(BASE_DIR, "embeddings", "face_db.pkl")
    if _face_db is None and os.path.exists(db_path):
        with open(db_path, "rb") as f:
            _face_db = pickle.load(f)
        print(f"[OK] Face DB loaded: {len(_face_db)} students")
    return _face_db

@app.route("/api/recognize", methods=["POST"])
def api_recognize():
    """Receive a base64 webcam frame, run ArcFace, return matches."""
    if not is_logged_in():
        return jsonify({"error": "Not logged in"}), 401

    import base64, numpy as np, cv2

    face_app = get_face_app()
    face_db  = get_face_db()

    if face_app is None or face_db is None:
        return jsonify({"error": "Face model not available",
                        "faces": []}), 200

    data_url = request.json.get("image", "")
    if "," in data_url:
        data_url = data_url.split(",")[1]

    try:
        img_bytes = base64.b64decode(data_url)
        np_arr    = np.frombuffer(img_bytes, np.uint8)
        frame     = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    except:
        return jsonify({"faces": []})

    if frame is None:
        return jsonify({"faces": []})

    faces   = face_app.get(frame)
    results = []

    for face in faces:
        embedding  = face.normed_embedding
        best_match = None
        best_score = 0.0

        for student_id, db_emb in face_db.items():
            score = float(np.dot(embedding, db_emb) /
                         (np.linalg.norm(embedding) *
                          np.linalg.norm(db_emb)))
            if score > best_score:
                best_score = score
                best_match = student_id

        box = face.bbox.astype(int).tolist()

        if best_score >= 0.5 and best_match:
            parts      = best_match.split("_", 1)
            enrollment = parts[0]
            name       = parts[1].replace("_", " ") \
                         if len(parts) > 1 else best_match
            results.append({
                "student_id": best_match,
                "name":       name,
                "enrollment": enrollment,
                "score":      round(best_score, 3),
                "box":        box,
                "status":     "recognized"
            })
        else:
            results.append({
                "student_id": None,
                "name":       "Unknown",
                "score":      round(best_score, 3),
                "box":        box,
                "status":     "unknown"
            })

    return jsonify({"faces": results})

@app.route("/api/mark-attendance", methods=["POST"])
def api_mark_attendance():
    """Mark a student present for a subject today."""
    if not is_logged_in():
        return jsonify({"error": "Not logged in"}), 401

    from database import insert_attendance, insert_class

    student_id   = request.json.get("student_id")
    subject_code = request.json.get("subject_code")
    if not student_id or not subject_code:
        return jsonify({"error": "Missing data"}), 400

    now  = datetime.now()
    d    = now.strftime("%Y-%m-%d")
    t    = now.strftime("%H:%M:%S")

    # Record class as held
    insert_class(subject_code, d, t)
    # Mark student present
    insert_attendance(student_id, subject_code, d, t, "Present")

    return jsonify({"success": True,
                    "student_id": student_id,
                    "date": d, "time": t})

@app.route("/api/mark-absent", methods=["POST"])
def api_mark_absent():
    """Mark remaining students absent for a subject today."""
    if not is_logged_in():
        return jsonify({"error": "Not logged in"}), 401

    from database import insert_attendance

    subject_code = request.json.get("subject_code")
    marked_ids   = request.json.get("marked_ids", [])
    if not subject_code:
        return jsonify({"error": "Missing subject"}), 400

    now = datetime.now()
    d   = now.strftime("%Y-%m-%d")
    t   = now.strftime("%H:%M:%S")

    all_stu = get_all_students()
    absent  = 0
    for s in all_stu:
        if s["student_id"] not in marked_ids:
            insert_attendance(s["student_id"], subject_code,
                              d, t, "Absent")
            absent += 1

    return jsonify({"success": True, "absent_count": absent})

# ─────────────────────────────────────────────
#  EMAIL ALERTS API
# ─────────────────────────────────────────────
@app.route("/api/send-alerts", methods=["POST"])
def api_send_alerts():
    """Send email alerts to students below threshold."""
    if not is_logged_in():
        return jsonify({"error": "Not logged in"}), 401
    user = get_current_user()
    if user["role"] != "teacher":
        return jsonify({"error": "Teachers only"}), 403

    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart

    # Email config from the alert system
    SENDER_EMAIL = "en23cs301565@medicaps.ac.in"
    APP_PASSWORD = "jyjc oguk htha fskw"
    SMTP_SERVER  = "smtp.gmail.com"
    SMTP_PORT    = 587

    config    = load_config()
    THRESHOLD = config.get("alert_threshold", 60)
    report    = get_attendance_report()

    # Find defaulters
    defaulters = {}
    for r in report:
        if r["pct"] < THRESHOLD and r["held"] > 0:
            sid = r["student_id"]
            if sid not in defaulters:
                defaulters[sid] = {
                    "name": r["name"],
                    "enrollment": r["enrollment"],
                    "email": r["email"],
                    "alerts": []
                }
            defaulters[sid]["alerts"].append({
                "subject": r["subject_name"],
                "present": r["present"],
                "held": r["held"],
                "absent": r["absent"],
                "pct": r["pct"],
            })

    if not defaulters:
        return jsonify({"success": True, "sent": 0, "failed": 0,
                        "message": "No defaulters found!"})

    # Send emails
    sent = 0
    failed = 0
    details = []

    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SENDER_EMAIL, APP_PASSWORD)
    except Exception as e:
        return jsonify({"error": f"SMTP connection failed: {str(e)}",
                        "sent": 0, "failed": len(defaulters)})

    for sid, info in defaulters.items():
        email = info["email"]
        if not email or email == "N/A" or "@" not in email:
            failed += 1
            details.append({"name": info["name"], "status": "no email"})
            continue

        # Build HTML email
        rows_html = ""
        for a in info["alerts"]:
            rows_html += f"""
            <tr style="background:#fff3e0">
              <td style="padding:8px;border:1px solid #ddd">{a['subject']}</td>
              <td style="padding:8px;border:1px solid #ddd;text-align:center">{a['present']}/{a['held']}</td>
              <td style="padding:8px;border:1px solid #ddd;text-align:center">{a['absent']}</td>
              <td style="padding:8px;border:1px solid #ddd;text-align:center;color:#c62828;font-weight:bold">{a['pct']}%</td>
            </tr>"""

        html_body = f"""
        <html><body style="font-family:Arial,sans-serif;color:#333">
          <div style="background:#1a237e;padding:20px;border-radius:8px 8px 0 0">
            <h2 style="color:white;margin:0">Low Attendance Alert</h2>
            <p style="color:#90caf9;margin:4px 0">{config['semester']['name']}</p>
          </div>
          <div style="padding:20px;border:1px solid #ddd;border-top:none;border-radius:0 0 8px 8px">
            <p>Dear <strong>{info['name']}</strong> ({info['enrollment']}),</p>
            <p>Your attendance is below <strong>{THRESHOLD}%</strong>:</p>
            <table style="width:100%;border-collapse:collapse;margin:16px 0">
              <tr style="background:#1a237e;color:white">
                <th style="padding:10px;border:1px solid #ddd;text-align:left">Subject</th>
                <th style="padding:10px;border:1px solid #ddd">Attended</th>
                <th style="padding:10px;border:1px solid #ddd">Absent</th>
                <th style="padding:10px;border:1px solid #ddd">Current %</th>
              </tr>
              {rows_html}
            </table>
            <p style="color:#c62828">Please attend classes regularly to avoid exam ineligibility.</p>
            <p style="color:#666;font-size:12px;margin-top:20px;border-top:1px solid #eee;padding-top:12px">
            Smart AI Attendance System | {datetime.now().strftime('%d-%m-%Y %H:%M:%S')}
            </p>
          </div>
        </body></html>"""

        subjects_str = ", ".join([a["subject"] for a in info["alerts"]])
        msg = MIMEMultipart("alternative")
        msg["From"]    = SENDER_EMAIL
        msg["To"]      = email
        msg["Subject"] = f"Low Attendance Alert - {subjects_str}"
        msg.attach(MIMEText(html_body, "html"))

        try:
            server.sendmail(SENDER_EMAIL, email, msg.as_string())
            sent += 1
            details.append({"name": info["name"], "email": email,
                           "status": "sent"})
        except Exception as e:
            failed += 1
            details.append({"name": info["name"], "status": f"failed: {str(e)}"})

    server.quit()
    return jsonify({"success": True, "sent": sent, "failed": failed,
                    "total_defaulters": len(defaulters),
                    "details": details})

# ─────────────────────────────────────────────
#  API ROUTES
# ─────────────────────────────────────────────
@app.route("/api/data")
def api_data():
    if not is_logged_in():
        return jsonify({"error":"Not logged in"}), 401
    return jsonify(load_data())

@app.route("/api/stats")
def api_stats():
    return jsonify(get_db_stats())

if __name__ == "__main__":
    print("=" * 50)
    print("  Smart AI Attendance System")
    print("=" * 50)
    print("\n  Teacher Login:")
    print("  Username: admin    Password: admin123")
    print("  Username: teacher  Password: teacher123")
    print("\n  Student Login:")
    print("  Username: enrollment number")
    print("  Password: last 4 digits of phone")
    print("\n  Open: http://localhost:5000")
    print("=" * 50)
    app.run(debug=True, host="0.0.0.0", port=5000)