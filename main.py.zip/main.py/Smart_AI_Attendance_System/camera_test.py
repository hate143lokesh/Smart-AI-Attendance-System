import cv2

# ── Auto-detect camera index & backend ──
def open_camera():
    backends = [cv2.CAP_ANY, cv2.CAP_DSHOW, cv2.CAP_V4L2]
    for idx in range(3):
        for backend in backends:
            try:
                cam = cv2.VideoCapture(idx, backend)
                if cam.isOpened():
                    ret, frame = cam.read()
                    if ret and frame is not None:
                        print(f"✅ Camera found at index {idx}")
                        return cam
                    cam.release()
            except Exception:
                continue
    return None

cam = open_camera()
if cam is None:
    print("❌ No camera found. Check:")
    print("   1. Camera is physically connected")
    print("   2. No other app is using the camera")
    print("   3. Camera permissions are enabled")
    exit()

print("🎥 Camera running. Press ESC to exit.")

consecutive_fails = 0

try:
    while True:
        ret, frame = cam.read()

        # ── Handle failed frames ──
        if not ret or frame is None:
            consecutive_fails += 1
            if consecutive_fails > 30:
                print("❌ Camera lost. Exiting.")
                break
            continue
        consecutive_fails = 0  # Reset on success

        cv2.imshow("Camera Test", frame)

        if cv2.waitKey(1) == 27:  # ESC to exit
            break

except KeyboardInterrupt:
    print("\n⚠️  Interrupted.")

finally:
    cam.release()           # Always release camera
    cv2.destroyAllWindows() # Always close windows
    print("✅ Camera released.")