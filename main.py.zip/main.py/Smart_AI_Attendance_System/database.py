import sqlite3
import os
import json
import csv
from datetime import datetime

# ─────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
DB_PATH     = os.path.join(BASE_DIR, "attendance.db")
SUBJECTS_FILE   = os.path.join(BASE_DIR, "subjects.json")
ATTENDANCE_FILE = os.path.join(BASE_DIR, "attendance.csv")
SCHEDULE_FILE   = os.path.join(BASE_DIR, "class_schedule.csv")
EMBEDDINGS_DIR  = os.path.join(BASE_DIR, "embeddings")

# ─────────────────────────────────────────────
#  STEP 1 — Connect to Database
# ─────────────────────────────────────────────
def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row   # ← access columns by name
    conn.execute("PRAGMA foreign_keys = OFF")  # relaxed for migration
    return conn

# ─────────────────────────────────────────────
#  STEP 2 — Create Tables
# ─────────────────────────────────────────────
def create_tables():
    conn = get_connection()
    cur  = conn.cursor()

    # Students table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id    TEXT    UNIQUE NOT NULL,
            name          TEXT    NOT NULL,
            enrollment    TEXT    NOT NULL,
            email         TEXT,
            phone         TEXT,
            registered_at TEXT    DEFAULT (datetime('now'))
        )
    """)

    # Subjects table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS subjects (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            code          TEXT    UNIQUE NOT NULL,
            name          TEXT    NOT NULL,
            teacher       TEXT,
            days          TEXT,
            time          TEXT,
            duration_mins INTEGER DEFAULT 60,
            total_classes INTEGER DEFAULT 0,
            created_at    TEXT    DEFAULT (datetime('now'))
        )
    """)

    # Class schedule table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS class_schedule (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            subject_code TEXT    NOT NULL,
            date         TEXT    NOT NULL,
            time         TEXT,
            UNIQUE(subject_code, date),
            FOREIGN KEY (subject_code)
                REFERENCES subjects(code)
        )
    """)

    # Attendance table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id   TEXT    NOT NULL,
            subject_code TEXT    NOT NULL,
            date         TEXT    NOT NULL,
            time         TEXT,
            status       TEXT    DEFAULT 'Present',
            UNIQUE(student_id, subject_code, date),
            FOREIGN KEY (student_id)
                REFERENCES students(student_id),
            FOREIGN KEY (subject_code)
                REFERENCES subjects(code)
        )
    """)

    conn.commit()
    conn.close()
    print("✅ Tables created successfully")

# ─────────────────────────────────────────────
#  STEP 3 — Insert / Update Functions
# ─────────────────────────────────────────────
def upsert_student(student_id, name, enrollment,
                   email="N/A", phone="N/A"):
    conn = get_connection()
    conn.execute("""
        INSERT INTO students
            (student_id, name, enrollment, email, phone)
        VALUES (?,?,?,?,?)
        ON CONFLICT(student_id) DO UPDATE SET
            name       = excluded.name,
            enrollment = excluded.enrollment,
            email      = excluded.email,
            phone      = excluded.phone
    """, (student_id, name, enrollment, email, phone))
    conn.commit()
    conn.close()

def upsert_subject(code, name, teacher, days,
                   time, duration_mins, total_classes):
    conn = get_connection()
    conn.execute("""
        INSERT INTO subjects
            (code, name, teacher, days, time,
             duration_mins, total_classes)
        VALUES (?,?,?,?,?,?,?)
        ON CONFLICT(code) DO UPDATE SET
            name          = excluded.name,
            teacher       = excluded.teacher,
            days          = excluded.days,
            time          = excluded.time,
            duration_mins = excluded.duration_mins,
            total_classes = excluded.total_classes
    """, (code, name, teacher,
          json.dumps(days), time,
          duration_mins, total_classes))
    conn.commit()
    conn.close()

def insert_class(subject_code, date, time):
    conn = get_connection()
    try:
        conn.execute("""
            INSERT OR IGNORE INTO class_schedule
                (subject_code, date, time)
            VALUES (?,?,?)
        """, (subject_code, date, time))
        conn.commit()
    except:
        pass
    finally:
        conn.close()

def insert_attendance(student_id, subject_code,
                      date, time, status="Present"):
    conn = get_connection()
    try:
        conn.execute("""
            INSERT INTO attendance
                (student_id, subject_code, date, time, status)
            VALUES (?,?,?,?,?)
            ON CONFLICT(student_id, subject_code, date)
            DO UPDATE SET
                status = excluded.status,
                time   = excluded.time
        """, (student_id, subject_code, date, time, status))
        conn.commit()
    except Exception as e:
        print(f"⚠️  Attendance insert error: {e}")
    finally:
        conn.close()

# ─────────────────────────────────────────────
#  STEP 4 — Query Functions
# ─────────────────────────────────────────────
def get_all_students():
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM students ORDER BY name"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_all_subjects():
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM subjects ORDER BY name"
    ).fetchall()
    conn.close()
    result = []
    for r in rows:
        d = dict(r)
        try:
            d["days"] = json.loads(d["days"])
        except:
            d["days"] = []
        result.append(d)
    return result

def get_classes_held(subject_code):
    conn = get_connection()
    count = conn.execute("""
        SELECT COUNT(*) FROM class_schedule
        WHERE subject_code = ?
    """, (subject_code,)).fetchone()[0]
    conn.close()
    return count

def get_attendance_count(student_id, subject_code):
    conn = get_connection()
    count = conn.execute("""
        SELECT COUNT(*) FROM attendance
        WHERE student_id   = ?
          AND subject_code = ?
          AND status       = 'Present'
    """, (student_id, subject_code)).fetchone()[0]
    conn.close()
    return count

def get_attendance_report():
    """Full attendance report — all students x subjects"""
    conn     = get_connection()
    students = conn.execute(
        "SELECT * FROM students ORDER BY name"
    ).fetchall()
    subjects = conn.execute(
        "SELECT * FROM subjects ORDER BY name"
    ).fetchall()

    report = []
    for student in students:
        for subject in subjects:
            held    = conn.execute("""
                SELECT COUNT(*) FROM class_schedule
                WHERE subject_code = ?
            """, (subject["code"],)).fetchone()[0]

            present = conn.execute("""
                SELECT COUNT(*) FROM attendance
                WHERE student_id   = ?
                  AND subject_code = ?
                  AND status       = 'Present'
            """, (student["student_id"],
                  subject["code"])).fetchone()[0]

            absent  = max(0, held - present)
            pct     = round((present / held * 100), 1) \
                      if held > 0 else 0
            status  = "OK" if pct >= 60 else "LOW"

            report.append({
                "student_id"  : student["student_id"],
                "name"        : student["name"],
                "enrollment"  : student["enrollment"],
                "email"       : student["email"],
                "phone"       : student["phone"],
                "subject_code": subject["code"],
                "subject_name": subject["name"],
                "present"     : present,
                "absent"      : absent,
                "held"        : held,
                "total"       : subject["total_classes"],
                "pct"         : pct,
                "status"      : status,
            })
    conn.close()
    return report

def get_defaulters(threshold=60):
    report = get_attendance_report()
    return [r for r in report
            if r["pct"] < threshold and r["held"] > 0]

def get_db_stats():
    conn = get_connection()
    stats = {
        "students"  : conn.execute(
            "SELECT COUNT(*) FROM students").fetchone()[0],
        "subjects"  : conn.execute(
            "SELECT COUNT(*) FROM subjects").fetchone()[0],
        "classes"   : conn.execute(
            "SELECT COUNT(*) FROM class_schedule").fetchone()[0],
        "attendance": conn.execute(
            "SELECT COUNT(*) FROM attendance").fetchone()[0],
        "present"   : conn.execute(
            "SELECT COUNT(*) FROM attendance "
            "WHERE status='Present'").fetchone()[0],
        "absent"    : conn.execute(
            "SELECT COUNT(*) FROM attendance "
            "WHERE status='Absent'").fetchone()[0],
    }
    conn.close()
    return stats

# ─────────────────────────────────────────────
#  STEP 5 — Migrate CSV → SQLite
# ─────────────────────────────────────────────
def migrate_from_csv():
    print("\n🔄 Migrating data to SQLite database...")

    # ── Auto-register unknown subjects from CSV ──
    if os.path.exists(ATTENDANCE_FILE):
        with open(ATTENDANCE_FILE) as f:
            for row in csv.DictReader(f):
                subj = row.get("Subject","").strip().lower()
                if not subj:
                    continue
                conn = get_connection()
                exists = conn.execute(
                    "SELECT id FROM subjects WHERE code=?",
                    (subj,)).fetchone()
                conn.close()
                if not exists:
                    upsert_subject(
                        code=subj, name=subj.upper(),
                        teacher="", days=[],
                        time="", duration_mins=60,
                        total_classes=0)
                    print(f"   ➕ Auto-added subject: {subj}")

    # ── Load subjects from JSON ──
    if os.path.exists(SUBJECTS_FILE):
        with open(SUBJECTS_FILE) as f:
            config = json.load(f)
        for s in config["subjects"]:
            upsert_subject(
                code          = s["code"],
                name          = s["name"],
                teacher       = s.get("teacher",""),
                days          = s.get("days",[]),
                time          = s.get("time",""),
                duration_mins = s.get("duration_mins", 60),
                total_classes = s.get("total_classes", 0),
            )
        print(f"   ✅ Subjects    : "
              f"{len(config['subjects'])} loaded")

    # ── Load students from embeddings JSON ──
    student_count = 0
    if os.path.exists(EMBEDDINGS_DIR):
        for file in os.listdir(EMBEDDINGS_DIR):
            if not file.endswith(".json"):
                continue
            try:
                with open(os.path.join(
                        EMBEDDINGS_DIR, file)) as f:
                    data = json.load(f)
                upsert_student(
                    student_id = data.get("student_id",""),
                    name       = data.get("name",""),
                    enrollment = data.get("enrollment",""),
                    email      = data.get("email","N/A"),
                    phone      = data.get("phone","N/A"),
                )
                student_count += 1
            except:
                continue
    print(f"   ✅ Students    : {student_count} loaded")

    # ── Load class schedule from CSV ──
    class_count = 0
    if os.path.exists(SCHEDULE_FILE):
        with open(SCHEDULE_FILE) as f:
            for row in csv.DictReader(f):
                subj = row.get("Subject","").strip().lower()
                date = row.get("Date","").strip()
                time = row.get("Time","").strip()
                if subj and date:
                    insert_class(subj, date, time)
                    class_count += 1
    print(f"   ✅ Classes     : {class_count} records loaded")

    # ── Load attendance from CSV ──
    att_count = 0
    if os.path.exists(ATTENDANCE_FILE):
        with open(ATTENDANCE_FILE) as f:
            for row in csv.DictReader(f):
                sid    = row.get("StudentID","").strip()
                subj   = row.get("Subject","").strip().lower()
                date   = row.get("Date","").strip()
                time   = row.get("Time","").strip()
                status = row.get("Status","Present").strip()
                if sid and subj and date:
                    insert_attendance(
                        sid, subj, date, time, status)
                    att_count += 1
    print(f"   ✅ Attendance  : {att_count} records loaded")
    print(f"\n✅ Migration complete → {DB_PATH}")

# ─────────────────────────────────────────────
#  MAIN — Run when executed directly
# ─────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 50)
    print("   SQLITE DATABASE SETUP")
    print("=" * 50 + "\n")

    # Create tables
    create_tables()

    # Migrate CSV data
    migrate_from_csv()

    # Show stats
    stats = get_db_stats()
    print(f"\n{'─'*50}")
    print(f"  Database Statistics")
    print(f"{'─'*50}")
    print(f"  Students    : {stats['students']}")
    print(f"  Subjects    : {stats['subjects']}")
    print(f"  Classes held: {stats['classes']}")
    print(f"  Attendance  : {stats['attendance']} records")
    print(f"  Present     : {stats['present']}")
    print(f"  Absent      : {stats['absent']}")
    print(f"{'─'*50}")
    print(f"\n  Database saved to: {DB_PATH}")
    print(f"  Size: {os.path.getsize(DB_PATH):,} bytes")
    print(f"{'─'*50}\n")
    print("✅ Database ready!")
    print("   All scripts can now use database.py")