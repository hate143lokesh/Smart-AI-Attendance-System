import os
import json
import pickle
import numpy as np
from datetime import datetime

# ─────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────
EMBEDDING_FOLDER = "embeddings"
DB_PATH          = "embeddings/face_db.pkl"

# ─────────────────────────────────────────────
#  STEP 1 — Validate Folder
# ─────────────────────────────────────────────
print("=" * 50)
print("   Building Face Embedding Database")
print("=" * 50)

if not os.path.exists(EMBEDDING_FOLDER):
    print(f"❌ '{EMBEDDING_FOLDER}' folder not found!")
    print("   Run register_student_arcface.py first.")
    exit()

json_files = [f for f in os.listdir(EMBEDDING_FOLDER)
              if f.endswith(".json")]

if len(json_files) == 0:
    print("❌ No student JSON files found in 'embeddings/'")
    print("   Run register_student_arcface.py first.")
    exit()

print(f"\n📂 Found {len(json_files)} student file(s).\n")

# ─────────────────────────────────────────────
#  STEP 2 — Load All Embeddings
# ─────────────────────────────────────────────
database = {}
skipped  = []
loaded   = []

for file in sorted(json_files):
    path = os.path.join(EMBEDDING_FOLDER, file)

    try:
        with open(path, "r") as f:
            data = json.load(f)

        # ── Validate required fields ──
        required = ["student_id", "embedding", "name", "enrollment"]
        missing  = [r for r in required if r not in data]

        if missing:
            print(f"  ⚠️  Skipping '{file}' — missing fields: {missing}")
            skipped.append(file)
            continue

        student_id = data["student_id"]
        name       = data["name"]
        enrollment = data["enrollment"]
        embedding  = np.array(data["embedding"], dtype=np.float32)

        # ── Validate embedding shape ──
        if embedding.ndim != 1 or embedding.shape[0] == 0:
            print(f"  ⚠️  Skipping '{file}' — invalid embedding shape.")
            skipped.append(file)
            continue

        # ── Re-normalize embedding ──
        norm = np.linalg.norm(embedding)
        if norm == 0:
            print(f"  ⚠️  Skipping '{file}' — zero norm embedding.")
            skipped.append(file)
            continue

        embedding = embedding / norm

        database[student_id] = embedding
        loaded.append({
            "student_id" : student_id,
            "name"       : name,
            "enrollment" : enrollment,
            "file"       : file
        })

        print(f"  ✅ Loaded: {name:20s} | {enrollment:15s} | {file}")

    except json.JSONDecodeError:
        print(f"  ❌ Skipping '{file}' — corrupted JSON file.")
        skipped.append(file)
    except Exception as e:
        print(f"  ❌ Skipping '{file}' — Error: {e}")
        skipped.append(file)

# ─────────────────────────────────────────────
#  STEP 3 — Validate Before Saving
# ─────────────────────────────────────────────
print(f"\n{'─'*50}")
print(f"  Loaded  : {len(loaded)} student(s)")
print(f"  Skipped : {len(skipped)} file(s)")
if skipped:
    for s in skipped:
        print(f"    └─ {s}")
print(f"{'─'*50}\n")

if len(database) == 0:
    print("❌ No valid embeddings to save. Aborting.")
    exit()

# ─────────────────────────────────────────────
#  STEP 4 — Save Database
# ─────────────────────────────────────────────
with open(DB_PATH, "wb") as f:
    pickle.dump(database, f)

print(f"💾 Database saved → '{DB_PATH}'")
print(f"   Students enrolled : {len(database)}")
print(f"   Embedding size    : {list(database.values())[0].shape[0]} dimensions")
print(f"   Built at          : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

# ─────────────────────────────────────────────
#  STEP 5 — Show Enrolled Students
# ─────────────────────────────────────────────
print(f"\n{'─'*50}")
print(f"  Enrolled Students")
print(f"{'─'*50}")
for i, student in enumerate(loaded, 1):
    print(f"  {i}. {student['name']:20s} | {student['enrollment']}")
print(f"{'─'*50}")
print(f"\n🎉 Database ready! Run take_attendance_arcface.py next.\n")