import os
import urllib.request

# 1. Create the folder
os.makedirs("models", exist_ok=True)

# 2. Define the files
files = {
    "deploy.prototxt": "https://raw.githubusercontent.com/opencv/opencv/master/samples/dnn/face_detector/deploy.prototxt",
    "res10_300x300_ssd_iter_140000.caffemodel": "https://github.com/opencv/opencv_3rdparty/raw/dnn_samples_face_detector_20170830/res10_300x300_ssd_iter_140000.caffemodel"
}

# 3. Download
for name, url in files.items():
    print(f"Downloading {name}...")
    urllib.request.urlretrieve(url, os.path.join("models", name))

print("✅ Done! Check the 'models' folder in your sidebar.")