import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import subprocess
import threading
import os
import sys
import webbrowser
import json
from datetime import datetime

# ─────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
PYTHON     = sys.executable
VENV_PY    = os.path.join(BASE_DIR, "venv310", "Scripts", "python.exe")

# Use venv python if available
if os.path.exists(VENV_PY):
    PYTHON = VENV_PY

# Colors
BG         = "#f0f2f5"
DARK_BLUE  = "#1a237e"
BLUE       = "#1565c0"
GREEN      = "#2e7d32"
RED        = "#c62828"
ORANGE     = "#e65100"
WHITE      = "#ffffff"
LIGHT_GRAY = "#f5f5f5"
GRAY       = "#424242"

# ─────────────────────────────────────────────
#  MAIN APP
# ─────────────────────────────────────────────
class SmartAttendanceLauncher:
    def __init__(self, root):
        self.root       = root
        self.flask_proc = None
        self.setup_window()
        self.build_ui()
        self.load_stats()

    # ── Window Setup ──
    def setup_window(self):
        self.root.title("Smart AI Attendance System")
        self.root.geometry("820x680")
        self.root.configure(bg=BG)
        self.root.resizable(False, False)

        # Center window
        self.root.update_idletasks()
        w = self.root.winfo_width()
        h = self.root.winfo_height()
        x = (self.root.winfo_screenwidth()  // 2) - (w // 2)
        y = (self.root.winfo_screenheight() // 2) - (h // 2)
        self.root.geometry(f"{w}x{h}+{x}+{y}")

        # Close handler
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    # ── Build UI ──
    def build_ui(self):

        # ── HEADER ──
        header = tk.Frame(self.root, bg=DARK_BLUE, height=80)
        header.pack(fill="x")
        header.pack_propagate(False)

        tk.Label(header,
            text="🎓 Smart AI Attendance System",
            font=("Segoe UI", 18, "bold"),
            bg=DARK_BLUE, fg=WHITE
        ).pack(side="left", padx=20, pady=10)

        # Status badge
        self.status_label = tk.Label(header,
            text="● System Ready",
            font=("Segoe UI", 10, "bold"),
            bg=DARK_BLUE, fg="#69f0ae")
        self.status_label.pack(side="right", padx=20)

        tk.Label(header,
            text="Medicaps University | InsightFace ArcFace",
            font=("Segoe UI", 9),
            bg=DARK_BLUE, fg="#90caf9"
        ).pack(side="right", padx=10)

        # ── STATS BAR ──
        stats_frame = tk.Frame(self.root, bg=BLUE, height=40)
        stats_frame.pack(fill="x")
        stats_frame.pack_propagate(False)

        self.stat_vars = {}
        for key, label in [
            ("students","Students"),
            ("subjects","Subjects"),
            ("classes","Classes Held"),
            ("present","Present Records"),
            ("absent","Absent Records"),
        ]:
            f = tk.Frame(stats_frame, bg=BLUE)
            f.pack(side="left", padx=20, pady=4)
            v = tk.StringVar(value="—")
            self.stat_vars[key] = v
            tk.Label(f, textvariable=v,
                font=("Segoe UI",11,"bold"),
                bg=BLUE, fg=WHITE).pack()
            tk.Label(f, text=label,
                font=("Segoe UI",8),
                bg=BLUE, fg="#90caf9").pack()

        # ── MAIN CONTENT ──
        content = tk.Frame(self.root, bg=BG)
        content.pack(fill="both", expand=True, padx=16, pady=12)

        # Left — buttons
        left = tk.Frame(content, bg=BG, width=380)
        left.pack(side="left", fill="y", padx=(0,12))
        left.pack_propagate(False)

        # Right — log
        right = tk.Frame(content, bg=BG)
        right.pack(side="left", fill="both", expand=True)

        # ── BUTTON SECTIONS ──
        sections = [
            {
                "title": "📋 Registration",
                "color": DARK_BLUE,
                "buttons": [
                    ("📸  Register New Student",
                     "register_student_arcface.py",
                     GREEN,
                     "Capture 5 photos + save embedding"),
                    ("🔄  Build Face Database",
                     "generate_embeddings.py",
                     BLUE,
                     "Combine all embeddings into face_db.pkl"),
                ]
            },
            {
                "title": "✅ Attendance",
                "color": DARK_BLUE,
                "buttons": [
                    ("🎥  Take Attendance",
                     "take_attendance_arcface.py",
                     GREEN,
                     "Open camera + mark attendance"),
                    ("📊  Run Calculator",
                     "attendance_calculator.py",
                     BLUE,
                     "Calculate % per student per subject"),
                ]
            },
            {
                "title": "📧 Alerts & Reports",
                "color": DARK_BLUE,
                "buttons": [
                    ("📧  Send Email Alerts",
                     "alert_system.py",
                     ORANGE,
                     "Email students below 60%"),
                    ("📥  Export Excel Report",
                     "export_excel.py",
                     BLUE,
                     "Generate color-coded .xlsx file"),
                ]
            },
            {
                "title": "🌐 Dashboard",
                "color": DARK_BLUE,
                "buttons": [
                    ("🚀  Start Web Dashboard",
                     "__flask__",
                     GREEN,
                     "Open browser dashboard at localhost:5000"),
                    ("🛑  Stop Dashboard",
                     "__stop__",
                     RED,
                     "Stop the Flask web server"),
                ]
            },
        ]

        for section in sections:
            # Section header
            sec_frame = tk.Frame(left, bg=section["color"],
                                 height=28)
            sec_frame.pack(fill="x", pady=(8,2))
            sec_frame.pack_propagate(False)
            tk.Label(sec_frame, text=section["title"],
                font=("Segoe UI",10,"bold"),
                bg=section["color"], fg=WHITE
            ).pack(side="left", padx=10, pady=4)

            # Buttons
            for btn_text, script, color, hint in \
                    section["buttons"]:
                btn_frame = tk.Frame(left, bg=WHITE,
                    relief="flat", bd=0)
                btn_frame.pack(fill="x", pady=2)

                btn = tk.Button(btn_frame,
                    text=btn_text,
                    font=("Segoe UI", 10, "bold"),
                    bg=color, fg=WHITE,
                    relief="flat", bd=0,
                    cursor="hand2",
                    padx=12, pady=8,
                    command=lambda s=script,
                                   t=btn_text: self.run_script(s,t)
                )
                btn.pack(fill="x")

                tk.Label(btn_frame,
                    text=f"  {hint}",
                    font=("Segoe UI", 8),
                    bg=WHITE, fg="#888",
                    anchor="w"
                ).pack(fill="x", padx=4)

                # Hover effect
                btn.bind("<Enter>", lambda e,b=btn,c=color:
                    b.configure(bg=self._darken(c)))
                btn.bind("<Leave>", lambda e,b=btn,c=color:
                    b.configure(bg=c))

        # Refresh button
        tk.Button(left,
            text="🔄  Refresh Stats",
            font=("Segoe UI",9,"bold"),
            bg=LIGHT_GRAY, fg=GRAY,
            relief="flat", cursor="hand2",
            pady=6,
            command=self.load_stats
        ).pack(fill="x", pady=(10,0))

        # ── LOG PANEL ── (right side)
        tk.Label(right,
            text="📋 Activity Log",
            font=("Segoe UI", 11, "bold"),
            bg=BG, fg=DARK_BLUE
        ).pack(anchor="w", pady=(0,4))

        self.log = scrolledtext.ScrolledText(
            right,
            font=("Consolas", 9),
            bg="#1e1e1e", fg="#d4d4d4",
            relief="flat", bd=0,
            state="disabled",
            wrap="word",
        )
        self.log.pack(fill="both", expand=True)

        # Log color tags
        self.log.tag_configure("success", foreground="#69f0ae")
        self.log.tag_configure("error",   foreground="#ef9a9a")
        self.log.tag_configure("info",    foreground="#90caf9")
        self.log.tag_configure("warning", foreground="#ffd54f")
        self.log.tag_configure("header",  foreground="#ffffff",
                               font=("Consolas",9,"bold"))

        # Clear log button
        tk.Button(right,
            text="🗑  Clear Log",
            font=("Segoe UI",9),
            bg=LIGHT_GRAY, fg=GRAY,
            relief="flat", cursor="hand2",
            pady=4,
            command=self.clear_log
        ).pack(fill="x", pady=(4,0))

        # ── FOOTER ──
        footer = tk.Frame(self.root, bg=WHITE, height=32)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)

        self.clock_var = tk.StringVar()
        tk.Label(footer,
            textvariable=self.clock_var,
            font=("Segoe UI",9),
            bg=WHITE, fg="#888"
        ).pack(side="left", padx=12, pady=6)

        tk.Label(footer,
            text="Built with InsightFace ArcFace + Flask + SQLite",
            font=("Segoe UI",9),
            bg=WHITE, fg="#888"
        ).pack(side="right", padx=12, pady=6)

        self.update_clock()
        self.log_msg("System initialized!", "success")
        self.log_msg(
            f"Python: {PYTHON}", "info")
        self.log_msg(
            "Ready — click a button to start", "info")

    # ── HELPERS ──
    def _darken(self, color):
        """Slightly darken a hex color"""
        r = int(color[1:3],16)
        g = int(color[3:5],16)
        b = int(color[5:7],16)
        r = max(0, r-30)
        g = max(0, g-30)
        b = max(0, b-30)
        return f"#{r:02x}{g:02x}{b:02x}"

    def update_clock(self):
        self.clock_var.set(
            datetime.now().strftime("%d %b %Y  %H:%M:%S"))
        self.root.after(1000, self.update_clock)

    def log_msg(self, msg, tag="info"):
        self.log.configure(state="normal")
        time_str = datetime.now().strftime("%H:%M:%S")
        self.log.insert("end", f"[{time_str}] ", "header")
        self.log.insert("end", f"{msg}\n", tag)
        self.log.see("end")
        self.log.configure(state="disabled")

    def clear_log(self):
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")

    def load_stats(self):
        """Load DB stats and update stat bar"""
        try:
            sys.path.insert(0, BASE_DIR)
            from database import get_db_stats
            stats = get_db_stats()
            self.stat_vars["students"].set(stats["students"])
            self.stat_vars["subjects"].set(stats["subjects"])
            self.stat_vars["classes"].set(stats["classes"])
            self.stat_vars["present"].set(stats["present"])
            self.stat_vars["absent"].set(stats["absent"])
            self.log_msg(
                f"Stats refreshed — "
                f"{stats['students']} students, "
                f"{stats['classes']} classes", "success")
        except Exception as e:
            self.log_msg(f"Stats error: {e}", "warning")

    # ── RUN SCRIPT ──
    def run_script(self, script, title):
        if script == "__flask__":
            self.start_flask()
            return
        if script == "__stop__":
            self.stop_flask()
            return

        script_path = os.path.join(BASE_DIR, script)
        if not os.path.exists(script_path):
            messagebox.showerror(
                "File Not Found",
                f"Script not found:\n{script_path}")
            return

        self.log_msg(f"Starting: {title}", "info")
        self.status_label.configure(
            text=f"● Running: {title[:25]}",
            fg="#ffd54f")

        def run():
            try:
                proc = subprocess.Popen(
                    [PYTHON, script_path],
                    cwd=BASE_DIR,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    creationflags=subprocess.CREATE_NEW_CONSOLE
                    if os.name=="nt" else 0,
                )
                self.log_msg(
                    f"Process started (PID {proc.pid})",
                    "success")
                proc.wait()
                self.root.after(0, lambda: [
                    self.log_msg(
                        f"Finished: {title}", "success"),
                    self.status_label.configure(
                        text="● System Ready",
                        fg="#69f0ae"),
                    self.load_stats(),
                ])
            except Exception as e:
                self.root.after(0, lambda: [
                    self.log_msg(f"Error: {e}", "error"),
                    self.status_label.configure(
                        text="● Error",
                        fg="#ef9a9a"),
                ])

        threading.Thread(target=run, daemon=True).start()

    def start_flask(self):
        if self.flask_proc and \
                self.flask_proc.poll() is None:
            self.log_msg(
                "Dashboard already running!", "warning")
            webbrowser.open("http://localhost:5000")
            return

        app_path = os.path.join(BASE_DIR, "app.py")
        if not os.path.exists(app_path):
            messagebox.showerror(
                "Not Found", "app.py not found!")
            return

        self.log_msg(
            "Starting Flask dashboard...", "info")
        self.status_label.configure(
            text="● Dashboard Running",
            fg="#69f0ae")

        def run():
            try:
                self.flask_proc = subprocess.Popen(
                    [PYTHON, app_path],
                    cwd=BASE_DIR,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                )
                import time
                time.sleep(2)
                self.root.after(0, lambda: [
                    self.log_msg(
                        "Dashboard ready → "
                        "http://localhost:5000",
                        "success"),
                    webbrowser.open(
                        "http://localhost:5000"),
                ])
                self.flask_proc.wait()
            except Exception as e:
                self.root.after(0, lambda:
                    self.log_msg(
                        f"Flask error: {e}", "error"))

        threading.Thread(target=run, daemon=True).start()

    def stop_flask(self):
        if self.flask_proc and \
                self.flask_proc.poll() is None:
            self.flask_proc.terminate()
            self.flask_proc = None
            self.log_msg(
                "Dashboard stopped", "warning")
            self.status_label.configure(
                text="● System Ready",
                fg="#69f0ae")
        else:
            self.log_msg(
                "Dashboard not running", "warning")

    def on_close(self):
        if self.flask_proc and \
                self.flask_proc.poll() is None:
            if messagebox.askyesno(
                "Quit",
                "Dashboard is running. Stop and quit?"):
                self.flask_proc.terminate()
                self.root.destroy()
        else:
            self.root.destroy()

# ─────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app  = SmartAttendanceLauncher(root)
    root.mainloop()