import cv2
import os
import re
import json
import numpy as np
from insightface.app import FaceAnalysis

# ─────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────
FACES_DIR      = "faces"
EMBEDDINGS_DIR = "embeddings"
TOTAL_PHOTOS   = 5
CONFIRM_FRAMES = 10
os.makedirs(FACES_DIR,      exist_ok=True)
os.makedirs(EMBEDDINGS_DIR, exist_ok=True)

# ─────────────────────────────────────────────
#  STEP 1 — Load InsightFace Model
# ─────────────────────────────────────────────
print("🔄 Loading ArcFace model...")
app = FaceAnalysis(name="buffalo_l")
app.prepare(ctx_id=0, det_size=(640, 640))
print("✅ Model loaded.\n")

# ─────────────────────────────────────────────
#  STEP 2 — Get & Validate Student Info
# ─────────────────────────────────────────────
def get_student_info():

    # ── Name ──
    while True:
        name = input("Enter Student Name        : ").strip().title()
        if re.match(r'^[A-Za-z\s]+$', name) and len(name) >= 2:
            break
        print("❌ Invalid name. Use letters only (min 2 characters).")

    # ── Enrollment ──
    while True:
        enrollment = input("Enter Enrollment Number   : ").strip().upper()
        if re.match(r'^[A-Za-z0-9_-]+$', enrollment) and len(enrollment) >= 3:
            break
        print("❌ Invalid enrollment. Use letters, numbers, - or _ only.")

    # ── Email ──
    while True:
        email = input("Enter Student Email        : ").strip().lower()
        if re.match(r'^[\w\.-]+@[\w\.-]+\.\w{2,}$', email):
            break
        print("❌ Invalid email. Example: student@gmail.com")

    # ── Phone ──
    while True:
        phone = input("Enter Student Phone (+91..): ").strip()
        cleaned = re.sub(r'[\s\-\(\)]', '', phone)
        if re.match(r'^(\+91)?[6-9]\d{9}$', cleaned):
            if not cleaned.startswith('+'):
                cleaned = '+91' + cleaned.lstrip('91') if cleaned.startswith('91') else '+91' + cleaned
            phone = cleaned
            break
        print("❌ Invalid phone. Example: 9876543210 or +919876543210")

    return name, enrollment, email, phone

print("=" * 50)
print("   Student Registration — ArcFace System")
print("=" * 50 + "\n")

name, enrollment, email, phone = get_student_info()

# Folder = faces/EN23CS301560_John_Doe
student_id     = f"{enrollment}_{name.replace(' ', '_')}"
student_folder = os.path.join(FACES_DIR, student_id)

print(f"\n{'─'*50}")
print(f"  Name       : {name}")
print(f"  Enrollment : {enrollment}")
print(f"  Email      : {email}")
print(f"  Phone      : {phone}")
print(f"{'─'*50}\n")

# ─────────────────────────────────────────────
#  STEP 3 — Check If Already Registered
# ─────────────────────────────────────────────
if os.path.exists(student_folder) and len(os.listdir(student_folder)) > 0:
    print(f"⚠️  '{student_id}' already registered "
          f"({len(os.listdir(student_folder))} photos found).")
    choice = input("Re-register? (y/n): ").strip().lower()
    if choice != 'y':
        print("Registration cancelled.")
        exit()
    import shutil
    shutil.rmtree(student_folder)
    print("🗑️  Old data removed.\n")

os.makedirs(student_folder, exist_ok=True)

# ─────────────────────────────────────────────
#  STEP 4 — Open Camera
# ─────────────────────────────────────────────
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    cap = cv2.VideoCapture(1)
    if not cap.isOpened():
        print("❌ No camera found.")
        exit()

print(f"📸 Registering: {name} ({enrollment})")
print(f"   Need {TOTAL_PHOTOS} photos")
print(f"   Press 'S' to capture | Press 'Q' to quit\n")

# ─────────────────────────────────────────────
#  STEP 5 — Capture Loop
# ─────────────────────────────────────────────
count             = 0
embeddings_list   = []
consecutive_fails = 0

while True:
    ret, frame = cap.read()

    if not ret or frame is None:
        consecutive_fails += 1
        if consecutive_fails > 30:
            print("❌ Camera lost.")
            break
        continue
    consecutive_fails = 0

    display = frame.copy()

    # Detect faces using InsightFace
    faces = app.get(frame)
    face_detected = len(faces) > 0

    if face_detected:
        for idx, face in enumerate(faces):
            box = face.bbox.astype(int)
            x1, y1, x2, y2 = box

            # Green box = face detected
            cv2.rectangle(display, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(display,
                        f"Face Ready | Score: {face.det_score:.2f}",
                        (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        # Progress bar
        bar_width = int((count / TOTAL_PHOTOS) * 300)
        cv2.rectangle(display, (10, 50), (310, 70), (50, 50, 50), -1)
        cv2.rectangle(display, (10, 50), (10 + bar_width, 70), (0, 255, 0), -1)
        cv2.putText(display,
                    f"Photos: {count}/{TOTAL_PHOTOS}",
                    (10, 45),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        cv2.putText(display,
                    "Press 'S' to capture",
                    (10, display.shape[0] - 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    else:
        # Red text = no face
        cv2.putText(display,
                    "No Face Detected — Move Closer",
                    (10, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

    # Student info on frame — now shows email too
    cv2.putText(display,
                f"{name} | {enrollment} | {email}",
                (10, display.shape[0] - 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1)

    cv2.imshow("Student Registration — ArcFace", display)

    key = cv2.waitKey(1) & 0xFF

    # ── S key = capture photo ──
    if key == ord('s') or key == ord('S'):
        if not face_detected:
            print("⚠️  No face detected! Move closer to camera.")
        elif len(faces) > 1:
            print("⚠️  Multiple faces detected! Only 1 student should be in frame.")
        else:
            count += 1
            face = faces[0]

            # Save photo
            img_path = os.path.join(student_folder, f"{count}.jpg")
            cv2.imwrite(img_path, frame)

            # Save ArcFace embedding (512-dim vector)
            embedding = face.normed_embedding
            embeddings_list.append(embedding.tolist())

            print(f"   ✅ Photo {count}/{TOTAL_PHOTOS} saved → {img_path}")

            if count >= TOTAL_PHOTOS:
                print(f"\n✅ All {TOTAL_PHOTOS} photos captured!")
                break

    # ── Q key = quit early ──
    elif key == ord('q') or key == ord('Q'):
        print(f"\n⚠️  Quit early — {count} photos saved.")
        break

cap.release()
cv2.destroyAllWindows()

# ─────────────────────────────────────────────
#  STEP 6 — Save Embeddings + Contact Info
# ─────────────────────────────────────────────
if len(embeddings_list) > 0:
    # Average all embeddings for better accuracy
    avg_embedding = np.mean(embeddings_list, axis=0)
    norm          = np.linalg.norm(avg_embedding)
    avg_embedding = (avg_embedding / norm).tolist()

    embedding_data = {
        "name"        : name,
        "enrollment"  : enrollment,
        "student_id"  : student_id,
        "email"       : email,          # ← NEW
        "phone"       : phone,          # ← NEW
        "photos_taken": count,
        "embedding"   : avg_embedding
    }

    emb_path = os.path.join(EMBEDDINGS_DIR, f"{student_id}.json")
    with open(emb_path, "w") as f:
        json.dump(embedding_data, f, indent=2)

    print(f"💾 Embedding + contact info saved → {emb_path}")

# ─────────────────────────────────────────────
#  DONE
# ─────────────────────────────────────────────
print(f"\n{'─'*50}")
print(f"  Registration Summary")
print(f"{'─'*50}")
print(f"  Name        : {name}")
print(f"  Enrollment  : {enrollment}")
print(f"  Email       : {email}")
print(f"  Phone       : {phone}")
print(f"  Photos      : {count}/{TOTAL_PHOTOS}")
print(f"  Folder      : {student_folder}")
print(f"  Status      : {'✅ Complete' if count >= TOTAL_PHOTOS else '⚠️ Incomplete'}")
print(f"{'─'*50}\n")
print("✅ Next: Run generate_embeddings.py to rebuild database.")
