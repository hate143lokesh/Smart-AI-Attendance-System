from flask import Flask, render_template, jsonify, send_file
import os, json
from datetime import datetime, date, timedelta
from database import (
    get_attendance_report,
    get_all_students,
    get_all_subjects,
    get_db_stats,
    get_connection
)

app = Flask(__name__)

BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
SUBJECTS_FILE = os.path.join(BASE_DIR, "subjects.json")

# ─────────────────────────────────────────────
#  DATA LOADER — reads from SQLite
# ─────────────────────────────────────────────
def load_data():
    # Load config
    with open(SUBJECTS_FILE) as f:
        config = json.load(f)
    ALERT_THRESHOLD = config.get("alert_threshold", 60)
    semester        = config["semester"]

    # Get data from database
    all_students = {s["student_id"]: s
                    for s in get_all_students()}
    all_subjects = {s["code"]: s
                    for s in get_all_subjects()}
    report       = get_attendance_report()
    stats        = get_db_stats()

    # Classes held per subject from DB
    conn         = get_connection()
    classes_held = {}
    for code in all_subjects:
        count = conn.execute("""
            SELECT COUNT(*) FROM class_schedule
            WHERE subject_code = ?
        """, (code,)).fetchone()[0]
        classes_held[code] = count

    # Expected classes from timetable
    DAY_MAP   = {"Monday":0,"Tuesday":1,"Wednesday":2,
                 "Thursday":3,"Friday":4,"Saturday":5,"Sunday":6}
    today     = date.today()
    sem_start = datetime.strptime(
        semester["start"],"%Y-%m-%d").date()
    sem_end   = datetime.strptime(
        semester["end"],"%Y-%m-%d").date()

    def expected(code):
        subj  = all_subjects.get(code)
        if not subj: return 0
        try:
            days = json.loads(subj["days"]) \
                   if isinstance(subj["days"], str) \
                   else subj["days"]
        except:
            days = []
        day_nums = [DAY_MAP.get(d, 0) for d in days]
        count    = 0
        check    = sem_start
        end      = min(today, sem_end)
        while check <= end:
            if check.weekday() in day_nums:
                count += 1
            check += timedelta(days=1)
        return count

    # Build results with projected %
    results = []
    for r in report:
        code = r["subject_code"]
        held = classes_held.get(code, 0)
        if held == 0:
            held = expected(code)

        subj  = all_subjects.get(code, {})
        total = subj.get("total_classes", 1) or 1
        proj  = round((r["present"] / total * 100), 1)

        results.append({
            **r,
            "held"        : held,
            "proj"        : proj,
            "subject_name": subj.get("name", code),
        })

    conn.close()

    return {
        "results"        : results,
        "all_students"   : all_students,
        "subjects_map"   : all_subjects,
        "classes_held"   : classes_held,
        "ALERT_THRESHOLD": ALERT_THRESHOLD,
        "semester"       : semester,
        "today"          : today.strftime("%d %B %Y"),
        "generated"      : datetime.now().strftime(
                           "%d-%m-%Y %H:%M:%S"),
        "db_stats"       : stats,
    }

# ─────────────────────────────────────────────
#  ROUTES
# ─────────────────────────────────────────────
@app.route("/")
def index():
    data       = load_data()
    results    = data["results"]
    defaulters = [r for r in results
                  if r["status"] == "LOW"
                  and r["held"] > 0]
    total_ok   = len([r for r in results
                      if r["status"] == "OK"])

    subject_stats = []
    for code, subj in data["subjects_map"].items():
        subj_results = [r for r in results
                        if r["subject_code"] == code]
        held      = data["classes_held"].get(code, 0)
        avg_pct   = round(
            sum(r["pct"] for r in subj_results)
            / len(subj_results), 1) if subj_results else 0
        low_count = len([r for r in subj_results
                         if r["status"] == "LOW"])
        subject_stats.append({
            "name"     : subj.get("name", code),
            "code"     : code,
            "held"     : held,
            "total"    : subj.get("total_classes", 0),
            "avg_pct"  : avg_pct,
            "low_count": low_count,
        })

    return render_template("index.html",
        data          = data,
        results       = results,
        defaulters    = defaulters,
        total_ok      = total_ok,
        subject_stats = subject_stats,
    )

@app.route("/api/data")
def api_data():
    return jsonify(load_data())

@app.route("/api/stats")
def api_stats():
    return jsonify(get_db_stats())

@app.route("/api/students")
def api_students():
    return jsonify(get_all_students())

@app.route("/api/report")
def api_report():
    return jsonify(get_attendance_report())

if __name__ == "__main__":
    print("🚀 Starting Flask Dashboard...")
    print("   Open: http://localhost:5000")
    print("   Phone: http://<your-ip>:5000")
    app.run(debug=True, host="0.0.0.0", port=5000)