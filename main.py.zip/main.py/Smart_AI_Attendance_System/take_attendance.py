import cv2
import pickle
import numpy as np
import csv
import os
import re
import json
from datetime import datetime, timedelta
from insightface.app import FaceAnalysis
from database import (
    insert_attendance,
    insert_class,
    get_all_students,
    upsert_subject,
    get_connection
)

# ─────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────
BASE_DIR        = os.path.dirname(os.path.abspath(__file__))
DB_PATH         = os.path.join(BASE_DIR, "embeddings", "face_db.pkl")
SUBJECTS_FILE   = os.path.join(BASE_DIR, "subjects.json")
EMBEDDINGS_DIR  = os.path.join(BASE_DIR, "embeddings")
THRESHOLD       = 0.5
FRAME_SKIP      = 3
CONFIRM_FRAMES  = 1
CLASS_DURATION  = 60   # ← 1 hour countdown

# ─────────────────────────────────────────────
#  STEP 1 — Load Model
# ─────────────────────────────────────────────
print("🔄 Loading ArcFace model...")
app = FaceAnalysis(name="buffalo_l")
app.prepare(ctx_id=0, det_size=(640, 640))
print("✅ Model loaded.")

# ─────────────────────────────────────────────
#  STEP 2 — Load Embedding Database
# ─────────────────────────────────────────────
if not os.path.exists(DB_PATH):
    print(f"❌ Database not found: {DB_PATH}")
    print("   Run generate_embeddings.py first.")
    exit()

with open(DB_PATH, "rb") as f:
    database = pickle.load(f)

print(f"✅ Embeddings loaded. {len(database)} student(s) enrolled.")

# ─────────────────────────────────────────────
#  STEP 3 — Load ALL Enrolled Students
# ─────────────────────────────────────────────
all_students = {}

for file in os.listdir(EMBEDDINGS_DIR):
    if not file.endswith(".json"):
        continue
    try:
        with open(os.path.join(EMBEDDINGS_DIR, file)) as f:
            data = json.load(f)
        sid = data.get("student_id", "")
        all_students[sid] = {
            "name"      : data.get("name", ""),
            "enrollment": data.get("enrollment", ""),
            "email"     : data.get("email", "N/A"),
            "phone"     : data.get("phone", "N/A"),
        }
    except:
        continue

print(f"✅ {len(all_students)} student(s) loaded.")

# ─────────────────────────────────────────────
#  STEP 4 — Load subjects.json + Get Subject
# ─────────────────────────────────────────────
subjects_map = {}

if os.path.exists(SUBJECTS_FILE):
    with open(SUBJECTS_FILE) as f:
        config = json.load(f)
    subjects_map = {s["code"]: s for s in config["subjects"]}
    print(f"\n📚 Available subjects:")
    for i, (code, subj) in enumerate(subjects_map.items(), 1):
        days_str = ", ".join([d[:3] for d in subj["days"]])
        print(f"   {i}. {code:<12} → {subj['name']:<25} "
              f"| {days_str} | {subj['time']}")

def get_subject():
    while True:
        name = input("\nEnter Subject Code: ").strip().lower()
        if subjects_map:
            if name in subjects_map:
                return name
            print(f"❌ Invalid. Choose from: "
                  f"{', '.join(subjects_map.keys())}")
        else:
            if re.match(r'^[a-z0-9 _-]+$', name) and len(name) > 0:
                return name
            print("❌ Invalid. Use letters, numbers, spaces only.")

subject      = get_subject()
today_date   = datetime.now().strftime("%Y-%m-%d")
subj_display = subjects_map[subject]["name"] \
               if subject in subjects_map else subject

# Show subject info
if subject in subjects_map:
    subj     = subjects_map[subject]
    days_str = ", ".join(subj["days"])
    print(f"\n📖 {subj_display}")
    print(f"   Days    : {days_str}")
    print(f"   Time    : {subj['time']}")
    print(f"   Teacher : {subj['teacher']}")
    print(f"   Total   : {subj['total_classes']} classes")

    # Ensure subject exists in SQLite
    upsert_subject(
        code          = subject,
        name          = subj["name"],
        teacher       = subj.get("teacher",""),
        days          = subj.get("days",[]),
        time          = subj.get("time",""),
        duration_mins = subj.get("duration_mins", 60),
        total_classes = subj.get("total_classes", 0),
    )

# ─────────────────────────────────────────────
#  STEP 5 — Start 1 Hour Countdown
# ─────────────────────────────────────────────
class_start = datetime.now()
deadline    = class_start + timedelta(minutes=CLASS_DURATION)

print(f"\n⏰ Countdown started: {CLASS_DURATION} mins")

# ─────────────────────────────────────────────
#  STEP 6 — Record Class as Held in DB
# ─────────────────────────────────────────────
insert_class(subject, today_date,
             class_start.strftime("%H:%M:%S"))
print(f"📅 Class recorded: {subject.upper()} on {today_date}")

# ─────────────────────────────────────────────
#  STEP 7 — Load Already Marked Today from DB
# ─────────────────────────────────────────────
marked_students = set()

conn = get_connection()
rows = conn.execute("""
    SELECT student_id FROM attendance
    WHERE subject_code = ?
      AND date         = ?
      AND status       = 'Present'
""", (subject, today_date)).fetchall()
conn.close()

for row in rows:
    marked_students.add(row["student_id"])

if marked_students:
    print(f"ℹ️  Already marked today: {len(marked_students)} student(s)")
else:
    print(f"ℹ️  No students marked yet for '{subject}' today.")

# ─────────────────────────────────────────────
#  STEP 8 — Mark Attendance Function → DB
# ─────────────────────────────────────────────
def mark_attendance(student_id, name, enrollment,
                    status="Present"):
    if student_id in marked_students and status == "Present":
        return False

    now  = datetime.now()
    date = now.strftime("%Y-%m-%d")
    time = now.strftime("%H:%M:%S")

    # ── Save to SQLite database ──
    insert_attendance(student_id, subject, date, time, status)

    if status == "Present":
        marked_students.add(student_id)
        print(f"✅ Present : {name} ({enrollment}) "
              f"| {subject.upper()} | {date}")
    return True

# ─────────────────────────────────────────────
#  STEP 9 — Cosine Similarity
# ─────────────────────────────────────────────
def cosine_similarity(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

# ─────────────────────────────────────────────
#  STEP 10 — Open Camera
# ─────────────────────────────────────────────
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    cap = cv2.VideoCapture(1)
    if not cap.isOpened():
        print("❌ No camera found.")
        exit()

print(f"\n🚀 Attendance started for: '{subj_display}'")
print(f"   Threshold      : {THRESHOLD}")
print(f"   Confirm frames : {CONFIRM_FRAMES}")
print(f"   ⏰ Auto-close  : {deadline.strftime('%H:%M')}")
print("   Press 'Q' to close manually.\n")

# ─────────────────────────────────────────────
#  STEP 11 — Main Recognition Loop
# ─────────────────────────────────────────────
frame_count       = 0
session_marked    = 0
consecutive_fails = 0
confirm_counters  = {}

try:
    while True:
        ret, frame = cap.read()

        if not ret or frame is None:
            consecutive_fails += 1
            if consecutive_fails > 30:
                print("❌ Camera lost. Exiting.")
                break
            continue
        consecutive_fails = 0
        frame_count      += 1

        current_time = datetime.now()

        # ── AUTO CLOSE after 1 hour ──
        if current_time >= deadline:
            print(f"\n⏰ 1 hour completed! Closing...")
            print(f"   Marking remaining students as Absent...")
            cv2.imshow(f"Attendance — {subj_display}", frame)
            cv2.waitKey(1000)
            break

        if frame_count % FRAME_SKIP != 0:
            cv2.imshow(f"Attendance — {subj_display}", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            continue

        display = frame.copy()
        faces   = app.get(frame)
        visible_this_frame = set()

        for face in faces:
            embedding  = face.normed_embedding
            best_match = None
            best_score = 0.0

            for student_id, db_embedding in database.items():
                score = cosine_similarity(embedding, db_embedding)
                if score > best_score:
                    best_score = score
                    best_match = student_id

            box = face.bbox.astype(int)
            x1, y1, x2, y2 = box

            if best_match:
                parts      = best_match.split("_", 1)
                enrollment = parts[0]
                name       = parts[1].replace("_", " ") \
                             if len(parts) > 1 else best_match
            else:
                enrollment = ""
                name       = "Unknown"

            if best_score >= THRESHOLD:
                visible_this_frame.add(best_match)
                confirm_counters[best_match] = \
                    confirm_counters.get(best_match, 0) + 1
                current_count = confirm_counters[best_match]

                if best_match in marked_students:
                    color = (255, 165, 0)
                    label = f"✓ {name} (Done)"

                elif current_count < CONFIRM_FRAMES:
                    color = (0, 255, 255)
                    label = (f"{name} "
                             f"({min(current_count, CONFIRM_FRAMES)}"
                             f"/{CONFIRM_FRAMES})")
                else:
                    newly = mark_attendance(
                        best_match, name, enrollment, "Present")
                    if newly:
                        session_marked += 1
                    color = (0, 255, 0)
                    label = f"✓ {name} Marked!"

            else:
                color = (0, 0, 255)
                label = f"Unknown ({best_score:.2f})"

            cv2.rectangle(display, (x1, y1), (x2, y2), color, 2)
            cv2.putText(display, label, (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

        for sid in list(confirm_counters.keys()):
            if sid not in visible_this_frame:
                confirm_counters[sid] = 0

        # ── AUTO CLOSE — all students marked ──
        if len(marked_students) >= len(database):
            print(f"\n🎉 All {len(database)} student(s) marked!")
            cv2.imshow(f"Attendance — {subj_display}", display)
            cv2.waitKey(1500)
            break

        # ── HUD — countdown timer ──
        h = display.shape[0]

        remaining_secs = int(
            (deadline - current_time).total_seconds())
        remaining_secs = max(0, remaining_secs)
        mins = remaining_secs // 60
        secs = remaining_secs % 60

        if remaining_secs > 600:
            timer_color = (200, 200, 200)
        elif remaining_secs > 300:
            timer_color = (0, 255, 255)
        elif remaining_secs > 60:
            timer_color = (0, 165, 255)
        else:
            timer_color = (0, 0, 255)

        cv2.putText(display,
                    f"⏰ Time Left: {mins:02d}:{secs:02d}",
                    (10, 35),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                    timer_color, 2)

        bar_total = CLASS_DURATION * 60
        bar_done  = bar_total - remaining_secs
        bar_width = int((bar_done / bar_total)
                        * (display.shape[1] - 20))
        cv2.rectangle(display,
                      (10, 45), (display.shape[1]-10, 55),
                      (50, 50, 50), -1)
        cv2.rectangle(display,
                      (10, 45), (10 + bar_width, 55),
                      timer_color, -1)

        hud = (f"{subj_display}  |  "
               f"Present: {len(marked_students)}/{len(database)}  |  "
               f"Remaining: {len(database)-len(marked_students)}")
        cv2.putText(display, hud, (10, h - 15),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (200, 200, 200), 1)

        cv2.imshow(f"Attendance — {subj_display}", display)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    print("\n⚠️  Interrupted.")

finally:
    cap.release()
    cv2.destroyAllWindows()

# ─────────────────────────────────────────────
#  STEP 12 — Mark ABSENT all remaining → DB
# ─────────────────────────────────────────────
print(f"\n📋 Marking absent students...")
absent_count = 0

for student_id, info in all_students.items():
    if student_id not in marked_students:
        mark_attendance(
            student_id,
            info["name"],
            info["enrollment"],
            "Absent"
        )
        print(f"❌ Absent : {info['name']} "
              f"({info['enrollment']}) | {subject.upper()}")
        absent_count += 1

# ─────────────────────────────────────────────
#  STEP 13 — Session Summary
# ─────────────────────────────────────────────
print(f"\n{'─'*50}")
print(f"  Session Summary")
print(f"{'─'*50}")
print(f"  Subject      : {subj_display}")
print(f"  Date         : {today_date}")
print(f"  Present      : {len(marked_students)}/{len(all_students)}")
print(f"  Absent       : {absent_count}/{len(all_students)}")
print(f"  This session : {session_marked}")
print(f"  Saved to     : attendance.db ✅")
print(f"{'─'*50}\n")