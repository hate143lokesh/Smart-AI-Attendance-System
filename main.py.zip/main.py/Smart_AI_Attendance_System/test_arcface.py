import cv2
from insightface.app import FaceAnalysis

# Initialize face analysis model
app = FaceAnalysis(name="buffalo_l")
app.prepare(ctx_id=0)   # 0 = CPU

# ─────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────
CONFIRM_FRAMES  = 10     # Frames needed to confirm detection
MAX_FACES       = 5      # Maximum faces to detect at once
COLORS = [
    (0, 255, 0),     # Green  — Face 1
    (255, 165, 0),   # Orange — Face 2
    (0, 255, 255),   # Yellow — Face 3
    (255, 0, 255),   # Purple — Face 4
    (0, 0, 255),     # Red    — Face 5
]

# ─────────────────────────────────────────────
#  Open Camera
# ─────────────────────────────────────────────
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    cap = cv2.VideoCapture(1)
    if not cap.isOpened():
        print("❌ No camera found.")
        exit()

print("📸 Camera started. Looking for faces...")
print(f"   Max faces     : {MAX_FACES}")
print(f"   Confirm frames: {CONFIRM_FRAMES}\n")

face_detected_count = 0   # consecutive frames with at least 1 face

while True:
    ret, frame = cap.read()

    if not ret or frame is None:
        print("⚠️  Camera not working.")
        break

    # Detect all faces in frame
    faces = app.get(frame)

    # Limit to MAX_FACES
    faces = faces[:MAX_FACES]

    total_faces = len(faces)

    if total_faces > 0:
        face_detected_count += 1

        for idx, face in enumerate(faces):
            box   = face.bbox.astype(int)
            x1, y1, x2, y2 = box
            color = COLORS[idx % len(COLORS)]

            # ── Draw rectangle for each face ──
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)

            # ── Label each face with number + color ──
            cv2.putText(frame,
                        f"Face {idx + 1}",
                        (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

            # ── Show detection confidence score ──
            cv2.putText(frame,
                        f"Score: {face.det_score:.2f}",
                        (x1, y2 + 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)

        # ── Top HUD — face count + confirm progress ──
        cv2.putText(frame,
                    f"Faces: {total_faces} | Confirming: {face_detected_count}/{CONFIRM_FRAMES}",
                    (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

        # ── Auto close after CONFIRM_FRAMES ──
        if face_detected_count >= CONFIRM_FRAMES:
            print(f"✅ Confirmed {total_faces} face(s) detected!")
            for i, face in enumerate(faces):
                print(f"   Face {i+1} — Detection Score: {face.det_score:.2f}")
            break

    else:
        # ── Reset count if no face found ──
        face_detected_count = 0
        cv2.putText(frame,
                    "No Face Detected — Move Closer",
                    (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

    # ── Bottom HUD — countdown ──
    remaining = max(0, CONFIRM_FRAMES - face_detected_count)
    cv2.putText(frame,
                f"Closing in {remaining} frames...",
                (10, frame.shape[0] - 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)

    cv2.imshow("ArcFace — Multi Face Detection", frame)

    if cv2.waitKey(1) == 13:   # ENTER to exit early
        break

cap.release()
cv2.destroyAllWindows()
print("🎉 Done!")
